REGIONS = {
    "Dar es Salaam": [
        "Ilala",
        "Kinondoni",
        "Temeke",
        "Ubungo",
        "Kigamboni"
    ],
    "Arusha": [
        "Arusha City",
        "Arumeru",
        "Monduli",
        "Karatu",
        "Longido"
    ],
    "Mwanza": [
        "Ilemela",
        "Nyamagana",
        "Sengerema",
        "Magu",
        "Kwimba"
    ],
    "Dodoma": [
        "Dodoma City",
        "Bahi",
        "Chamwino",
        "Kondoa",
        "Mpwapwa"
    ]
}
