from setuptools import setup, find_packages

setup(
    name='tanzania-locations',
    version='1.0.0',
    author='Cornel Mtavangu',
    packages = find_packages(),
    install_requires=[],
    description='A package for managing Tanzania locations data',
)