from setuptools import setup, find_packages

setup(
    name='tanzania_locations',
    version='1.1.0',
    author='Cornel Mtavangu',
    packages = find_packages(),
    install_requires=[],
    description='A package for managing Tanzania locations data',
)