# tz-regions 🇹🇿

A lightweight Python package providing Tanzania regions and districts.
Perfect for Django forms and APIs.

## Installation
```bash
pip install tz-regions
